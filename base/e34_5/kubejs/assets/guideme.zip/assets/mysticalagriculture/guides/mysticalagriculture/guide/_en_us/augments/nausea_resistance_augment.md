---
navigation:
  title: "Nausea Resistance Augment"
  icon: "mysticalagriculture:nausea_resistance_augment"
  position: 319
  parent: mysticalagriculture:augments.md
---

# Nausea Resistance Augment

The Nausea Resistance Augment is a helmet augment that prevents the wearer from getting the Nausea effect while they have the armor equipped.

