---
navigation:
  title: "Soul Extractor"
  icon: "mysticalagriculture:soul_extractor"
  position: 203
  parent: mysticalagriculture:machines.md
item_ids:
  - mysticalagriculture:soul_extractor
---

# Soul Extractor

Soul Extractors are used to convert mob drops into mob souls. They run off of solid fuels and have an internal power storage buffer. 

The Soul Extractor provides a use for extra mob drops you may have, but generally won't be as efficient as using a [Soulium Dagger](../souls/soulium_dagger.md).

## Crafting



<Recipe id="mysticalagriculture:soul_extractor" />

