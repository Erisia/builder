---
navigation:
  title: "Flächenbearbeitung-Augment"
  icon: "mysticalagriculture:tilling_aoe_iv_augment"
  position: 308
  parent: mysticalagriculture:augments.md
---

# Flächenbearbeitung-Augment

Das Flächenbearbeitung-Augment ist ein Hacken-Augment, das den Bereich vergrößert, in dem die Hacke Ackerlandblöcke erstellt, bis zu 9x9. Das AOE wird aktiviert, indem man beim Benutzen der Hacke schleicht. 

Dieser Effekt kann durch Halten der Umschalttaste negiert werden.

