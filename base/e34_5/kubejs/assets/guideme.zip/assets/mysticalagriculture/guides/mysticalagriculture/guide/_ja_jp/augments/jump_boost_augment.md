---
navigation:
  title: "跳躍力上昇のオーグメント"
  icon: "mysticalagriculture:jump_boost_iii_augment"
  position: 305
  parent: mysticalagriculture:augments.md
---

# 跳躍力上昇のオーグメント

跳躍力上昇のオーグメントは、着用者の跳躍力を増加させるブーツ用のオーグメントです。

