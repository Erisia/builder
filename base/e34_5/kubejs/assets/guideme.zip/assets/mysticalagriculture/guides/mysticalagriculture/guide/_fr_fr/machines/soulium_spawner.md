---
navigation:
  title: undefined
  icon: "mysticalagriculture:soulium_spawner"
  position: 205
  parent: mysticalagriculture:machines.md
item_ids:
  - mysticalagriculture:soulium_spawner
---

# undefined



## Fabrication



<Recipe id="mysticalagriculture:soulium_spawner" />

