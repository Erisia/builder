---
navigation:
  title: "Essence Tools"
  icon: "mysticalagriculture:inferium_pickaxe"
  position: 250
  parent: mysticalagriculture:tinkering.md
item_ids:
  - mysticalagriculture:inferium_pickaxe
---

# Essence Tools

Upgrading your Diamond* tools with essence improves their durability and mining speed. This also allows them to be equipped with [Augments](./augments.md). 

Essence Tools can be repaired in an Anvil with their corresponding Essence Ingot. These tools each have 1 augment slot.

## Fabrication



<Recipe id="mysticalagriculture:gear/inferium_pickaxe" />

