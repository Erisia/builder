---
navigation:
  title: "神秘の肥料"
  icon: "mysticalagriculture:mystical_fertilizer"
  position: 50
  parent: mysticalagriculture:advances.md
item_ids:
  - mysticalagriculture:mystical_fertilizer
---

# 神秘の肥料

神秘の肥料は、作物や苗木を瞬時に成長させることができます。[資源の作物](../basics/resource_crops.md)にも使用することができます！

## クラフト



<Recipe id="mysticalagriculture:mystical_fertilizer" />

<Recipe id="mysticalagriculture:mystical_fertilizer_better" />

