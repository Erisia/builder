---
navigation:
  title: "移動速度上昇のオーグメント"
  icon: "mysticalagriculture:speed_iii_augment"
  position: 306
  parent: mysticalagriculture:augments.md
---

# 移動速度上昇のオーグメント

移動速度上昇のオーグメントは、着用者の移動速度を増加させるレギンス用のオーグメントです。この効果は飛行速度にも適用されます。

