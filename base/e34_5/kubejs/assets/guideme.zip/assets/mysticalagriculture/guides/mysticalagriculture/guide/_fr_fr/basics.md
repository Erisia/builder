---
navigation:
  title: "Les Bases"
  icon: "mysticalagriculture:inferium_essence"
---

# Les Bases

<SubPages />