---
navigation:
  title: "Essenz-Ofen"
  icon: "mysticalagriculture:furnace"
  position: 201
  parent: mysticalagriculture:machines.md
item_ids:
  - mysticalagriculture:furnace
---

# Essenz-Ofen

Der Basisofen kann aufgerüstet werden, um [Maschinen-Upgrades](./machine_upgrades.md) für eine erhöhte Schmelzgeschwindigkeit zu nutzen. Er läuft mit festen Brennstoffen und haben einen internen Energiespeicher.

## Werkbank



<Recipe id="mysticalagriculture:furnace" />

