---
navigation:
  title: "Infusionskristall"
  icon: "mysticalagriculture:infusion_crystal"
  position: 2
  parent: mysticalagriculture:basics.md
item_ids:
  - mysticalagriculture:infusion_crystal
  - mysticalagriculture:prudentium_essence
---

# Infusionskristall

Der Infusionskristall wird verwendet, um höherstufige Essenzen herzustellen.

## Werkbank



<Recipe id="mysticalagriculture:infusion_crystal" />

<Recipe id="mysticalagriculture:prudentium_essence" />

