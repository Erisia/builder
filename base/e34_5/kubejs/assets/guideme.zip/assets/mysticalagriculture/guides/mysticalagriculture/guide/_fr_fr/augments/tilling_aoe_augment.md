---
navigation:
  title: "Tilling AOE Augment"
  icon: "mysticalagriculture:tilling_aoe_iv_augment"
  position: 308
  parent: mysticalagriculture:augments.md
---

# Tilling AOE Augment

The Tilling AOE Augment is a hoe augment that increases the area that the hoe creates Farmland blocks, up to 9x9. The AOE is activated by sneaking while using the hoe.

