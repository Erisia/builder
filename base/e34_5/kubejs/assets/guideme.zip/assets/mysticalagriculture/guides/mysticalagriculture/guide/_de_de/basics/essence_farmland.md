---
navigation:
  title: "Essenz-Ackerland"
  icon: "mysticalagriculture:inferium_farmland"
  position: 6
  parent: mysticalagriculture:basics.md
item_ids:
  - mysticalagriculture:inferium_farmland
---

# Essenz-Ackerland

Essenz-Ackerland erhöht die Effizienz der Pflanzen auf verschiedene Weise. Diese sind auf der folgenden Seite aufgeführt. 

Essenz-Ackerland kann entweder durch Rechtsklick auf Ackerland mit einer Essenz oder durch Handwerk erstellt werden.


- Pflanzen haben **normalerweise** eine 10-prozentige Chance, einen zweiten Samen fallen zu lassen, wenn sie auf irgendeinem Essenz-Ackerland gepflanzt werden. 
- Pflanzen haben eine zusätzliche 10-prozentige Chance, einen zweiten Samen fallen zu lassen, wenn sie auf dem entsprechenden Essenz-Ackerland gepflanzt werden. 
- Inferiumsamen lassen mehr Essenzen fallen, wenn sie auf höherstufigem Essenz-Ackerland gepflanzt werden.

## Werkbank



<Recipe id="mysticalagriculture:inferium_farmland" />

<Recipe id="mysticalagriculture:inferium_farmland_till" />

