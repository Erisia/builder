---
navigation:
  title: "Inferium Seeds"
  icon: "mysticalagriculture:inferium_seeds"
  position: 3
  parent: mysticalagriculture:basics.md
item_ids:
  - mysticalagriculture:inferium_seeds
---

# Inferium Seeds

Inferium Seeds are one of the main ways to collect Inferium Essence. They can be grown on any farmland, but are most efficient on [Essence Farmland](./essence_farmland.md).

## Fabrication



<Recipe id="mysticalagriculture:inferium_seeds" />

