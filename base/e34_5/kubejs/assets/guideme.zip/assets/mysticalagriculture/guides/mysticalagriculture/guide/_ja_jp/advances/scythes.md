---
navigation:
  title: "大鎌"
  icon: "mysticalagriculture:inferium_scythe"
  position: 54
  parent: mysticalagriculture:advances.md
item_ids:
  - mysticalagriculture:diamond_scythe
  - mysticalagriculture:inferium_scythe
---

# 大鎌

大鎌は、右クリックで広範囲の作物を収穫することができます。範囲内の完全に成長した作物を破壊することなく収穫できます。

大鎌は、広い攻撃範囲を持つ武器としても使用できます。

高ランクの大鎌は、より広い効果範囲を持ちます。

## クラフト



<Recipe id="mysticalagriculture:diamond_scythe" />

<Recipe id="mysticalagriculture:gear/inferium_scythe" />

