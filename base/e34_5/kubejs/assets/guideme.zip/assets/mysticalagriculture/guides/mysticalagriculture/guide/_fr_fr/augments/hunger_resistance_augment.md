---
navigation:
  title: undefined
  icon: "mysticalagriculture:hunger_resistance_augment"
  position: 318
  parent: mysticalagriculture:augments.md
---

# undefined



