---
navigation:
  title: "Oberwelt-Erze"
  icon: "mysticalagriculture:inferium_ore"
  position: 4
  parent: mysticalagriculture:basics.md
---

# Oberwelt-Erze

<ItemImage id="mysticalagriculture:inferium_ore" />

Inferiumerz **normalerweise** spawnt zwischen Y-Level -32 und 64 in der Oberwelt.

<ItemImage id="mysticalagriculture:prosperity_ore" />

Prosperiumerz **normalerweise** spawnt zwischen Y-Level -60 und 24 in der Oberwelt.

