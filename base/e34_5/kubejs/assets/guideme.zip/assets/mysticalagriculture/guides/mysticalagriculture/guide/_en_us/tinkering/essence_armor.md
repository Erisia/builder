---
navigation:
  title: "Essence Armor"
  icon: "mysticalagriculture:inferium_chestplate"
  position: 251
  parent: mysticalagriculture:tinkering.md
item_ids:
  - mysticalagriculture:inferium_chestplate
---

# Essence Armor

Upgrading your Diamond* armor with essence improves its durability and protection. This also allows them to be equipped with [Augments](./augments.md). 

Essence Armor can be repaired in an Anvil with their corresponding Essence Ingot. These armor pieces each have 1 augment slot.

## Crafting



<Recipe id="mysticalagriculture:gear/inferium_chestplate" />

