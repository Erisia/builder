---
navigation:
  title: "Haste Augment"
  icon: "mysticalagriculture:haste_iii_augment"
  position: 323
  parent: mysticalagriculture:augments.md
---

# Haste Augment

The Haste Augment is a chestplate augment that increases the wearer's mining speed while they have the armor equipped.

