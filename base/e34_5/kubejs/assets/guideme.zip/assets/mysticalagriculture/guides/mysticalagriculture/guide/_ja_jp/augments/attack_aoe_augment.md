---
navigation:
  title: "範囲攻撃のオーグメント"
  icon: "mysticalagriculture:attack_aoe_iii_augment"
  position: 312
  parent: mysticalagriculture:augments.md
---

# 範囲攻撃のオーグメント

範囲攻撃のオーグメントは、剣の攻撃範囲を最大6ブロック分増加させる剣用のオーグメントです。

