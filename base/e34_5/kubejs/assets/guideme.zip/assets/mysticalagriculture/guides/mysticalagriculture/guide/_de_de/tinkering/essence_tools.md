---
navigation:
  title: "Essenzwerkzeuge"
  icon: "mysticalagriculture:inferium_pickaxe"
  position: 250
  parent: mysticalagriculture:tinkering.md
item_ids:
  - mysticalagriculture:inferium_pickaxe
---

# Essenzwerkzeuge

Das Aufrüsten der Diamant*-Werkzeuge mit Essenzen verbessert deren Haltbarkeit und Abbaugeschwindigkeit. Dies ermöglicht auch die Ausrüstung mit [Augments](./augments.md). 

Essenzwerkzeuge können in einem Amboss mit ihrem entsprechenden Essenzbarren repariert werden. Diese Werkzeuge haben jeweils 1 Augment-Slot.

## Werkbank



<Recipe id="mysticalagriculture:gear/inferium_pickaxe" />

