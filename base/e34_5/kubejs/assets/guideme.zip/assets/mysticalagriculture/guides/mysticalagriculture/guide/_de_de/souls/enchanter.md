---
navigation:
  title: "Verzauberer"
  icon: "mysticalagriculture:enchanter"
  position: 110
  parent: mysticalagriculture:souls.md
item_ids:
  - mysticalagriculture:enchanter
---

# Verzauberer

Der Verzauberer ist ein Block, der es ermöglicht, Werkzeuge und Rüstungen mit verschiedenen Handwerksmaterialien und Erfahrungsessenz zu verzaubern. 

Der Verzauberer kann Verzauberungen sowohl auf Bücher als auch auf Werkzeuge/Rüstungen anwenden, ähnlich wie ein Amboss.

## Werkbank



<Recipe id="mysticalagriculture:enchanter" />

