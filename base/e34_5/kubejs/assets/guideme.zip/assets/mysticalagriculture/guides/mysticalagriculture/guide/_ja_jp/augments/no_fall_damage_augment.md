---
navigation:
  title: "落下ダメージ無効のオーグメント"
  icon: "mysticalagriculture:no_fall_damage_augment"
  position: 308
  parent: mysticalagriculture:augments.md
---

# 落下ダメージ無効のオーグメント

落下ダメージ無効のオーグメントは、着用者の落下ダメージを無効化するブーツ用のオーグメントです。

