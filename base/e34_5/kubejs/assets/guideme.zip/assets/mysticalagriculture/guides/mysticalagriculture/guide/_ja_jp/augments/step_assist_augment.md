---
navigation:
  title: "歩行補助のオーグメント"
  icon: "mysticalagriculture:step_assist_augment"
  position: 310
  parent: mysticalagriculture:augments.md
---

# 歩行補助のオーグメント

歩行補助のオーグメントは、着用者が1ブロックの段差をジャンプせずに越えられるようにするレギンスまたはブーツ用のオーグメントです。

この効果はShiftキーを押している間は無効化されます。

