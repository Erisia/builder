---
navigation:
  title: "範囲耕うんのオーグメント"
  icon: "mysticalagriculture:tilling_aoe_iv_augment"
  position: 308
  parent: mysticalagriculture:augments.md
---

# 範囲耕うんのオーグメント

範囲耕うんのオーグメントは、クワが土を耕す範囲を最大9x9まで増加させるクワのオーグメントです。この効果はスニークしながらクワを使用したときのみ発動します。

