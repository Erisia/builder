---
navigation:
  title: "Schwäche-Resistenz-Augment"
  icon: "mysticalagriculture:weakness_resistance_augment"
  position: 321
  parent: mysticalagriculture:augments.md
---

# Schwäche-Resistenz-Augment

Das Schwäche-Resistenz-Augment ist ein Brustpanzer-Augment, das verhindert, dass der Träger den Schwächeeffekt erhält, solange er die Rüstung trägt.

