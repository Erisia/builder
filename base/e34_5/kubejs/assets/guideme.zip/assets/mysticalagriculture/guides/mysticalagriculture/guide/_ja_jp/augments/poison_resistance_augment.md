---
navigation:
  title: "毒耐性のオーグメント"
  icon: "mysticalagriculture:poison_resistance_augment"
  position: 313
  parent: mysticalagriculture:augments.md
---

# 毒耐性のオーグメント

毒耐性のオーグメントは、着用者の毒の効果を防ぐ防具用のオーグメントです。

