---
navigation:
  title: "衝撃吸収のオーグメント"
  icon: "mysticalagriculture:absorption_v_augment"
  position: 300
  parent: mysticalagriculture:augments.md
---

# 衝撃吸収のオーグメント

衝撃吸収のオーグメントは、8分ごとに着用者にハート2-10個分の衝撃吸収を付与する防具用のオーグメントです。

