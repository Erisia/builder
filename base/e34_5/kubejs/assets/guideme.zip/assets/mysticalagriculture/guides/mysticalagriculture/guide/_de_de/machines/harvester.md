---
navigation:
  title: "Ernter"
  icon: "mysticalagriculture:harvester"
  position: 204
  parent: mysticalagriculture:machines.md
item_ids:
  - mysticalagriculture:harvester
---

# Ernter

Ernter werden verwendet, um voll ausgewachsene Pflanzen automatisch zu ernten. Sie laufen mit festen Brennstoffen und haben einen internen Energiespeicher. 

Der Ernter pflanzt die geernteten Pflanzen automatisch neu. 

Der Ernter legt alle Ressourcen in sein internes Inventar. Wenn kein Platz vorhanden ist, werden die Gegenstände auf die Pflanze gelegt.

## Werkbank

Der Ernter verbraucht bei jeder Überprüfung einer Pflanze auf Wachstum etwas Energie. Das Ernten voll ausgewachsener Pflanzen verbraucht eine erhöhte Energiemenge. 

Diese Maschinen können mit [Maschinen-Upgrades](./machine_upgrades.md) aufgerüstet werden. 

Der Ernter kann mit einem Redstonesignal deaktiviert werden.

<Recipe id="mysticalagriculture:harvester" />

