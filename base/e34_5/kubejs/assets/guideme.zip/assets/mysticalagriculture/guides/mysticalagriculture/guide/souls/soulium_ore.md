---
navigation:
  title: "Soulium Ore"
  icon: "mysticalagriculture:soulium_ore"
  position: 101
  parent: mysticalagriculture:souls.md
---

# Soulium Ore

<ItemImage id="mysticalagriculture:soulium_ore" />

Soulium Ore **usually** spawns inside [Soulstone](./soulstone.md) veins in the Nether.

