---
navigation:
  title: "Souls"
  icon: "mysticalagriculture:soulium_dagger"
  position: 2
---

# Souls

<SubPages />