---
navigation:
  title: "Cognizant Dust"
  icon: "mysticalagriculture:cognizant_dust"
  position: 151
  parent: mysticalagriculture:elemental.md
---

# Cognizant Dust

Cognizant Dust is **usually** obtained by killing a Wither or Ender Dragon using an [Essence Weapon](../tinkering/essence_tools.md) enchanted with Mystical Enlightenment. 

Higher levels of Mystical Enlightenment will increase the amount of dust dropped on kill.

