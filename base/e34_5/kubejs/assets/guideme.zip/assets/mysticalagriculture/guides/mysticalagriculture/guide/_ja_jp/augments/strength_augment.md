---
navigation:
  title: "攻撃力上昇のオーグメント"
  icon: "mysticalagriculture:strength_iii_augment"
  position: 311
  parent: mysticalagriculture:augments.md
---

# 攻撃力上昇のオーグメント

攻撃力上昇のオーグメントは、剣の攻撃力を5-20増加させる剣用のオーグメントです。

