---
navigation:
  title: "Langsamkeitsresistenz-Augment"
  icon: "mysticalagriculture:slowness_resistance_augment"
  position: 320
  parent: mysticalagriculture:augments.md
---

# Langsamkeitsresistenz-Augment

Das Langsamkeitsresistenz-Augment ist ein Hosen-Augment, das verhindert, dass der Träger den Langsamkeitseffekt erhält, solange er die Rüstung trägt.

