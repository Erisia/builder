---
navigation:
  title: "鎌"
  icon: "mysticalagriculture:inferium_sickle"
  position: 53
  parent: mysticalagriculture:advances.md
item_ids:
  - mysticalagriculture:diamond_sickle
  - mysticalagriculture:inferium_sickle
---

# 鎌

鎌は、広範囲の植物を収穫／破壊することができます。

高ランクの鎌は、より広い効果範囲を持ちます。

## クラフト



<Recipe id="mysticalagriculture:diamond_sickle" />

<Recipe id="mysticalagriculture:gear/inferium_sickle" />

