---
navigation:
  title: "Gesundheitsboost-Augment"
  icon: "mysticalagriculture:health_boost_v_augment"
  position: 301
  parent: mysticalagriculture:augments.md
---

# Gesundheitsboost-Augment

Das Gesundheitsboost-Augment ist ein Rüstungs-Augment, das dem Träger 2-10 zusätzliche Herzen verleiht, während die Rüstung getragen wird.

