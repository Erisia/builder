---
navigation:
  title: "Pathing AOE Augment"
  icon: "mysticalagriculture:pathing_aoe_iv_augment"
  position: 304
  parent: mysticalagriculture:augments.md
---

# Pathing AOE Augment

The Pathing AOE Augment is a shovel augment that increases the area that the shovel creates Path blocks, up to 9x9. The AOE is activated by sneaking while using the shovel. 

This effect can be negated by holding down the Shift key.

