---
navigation:
  title: "Blindheitsresistenz-Augment"
  icon: "mysticalagriculture:blindness_resistance_augment"
  position: 317
  parent: mysticalagriculture:augments.md
---

# Blindheitsresistenz-Augment

Das Blindheitsresistenz-Augment ist ein Helm-Augment, das verhindert, dass der Träger den Blindheitseffekt erhält, solange er die Rüstung trägt.

