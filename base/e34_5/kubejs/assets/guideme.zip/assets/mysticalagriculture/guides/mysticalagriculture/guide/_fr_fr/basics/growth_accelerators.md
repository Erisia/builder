---
navigation:
  title: "Growth Accelerators"
  icon: "mysticalagriculture:inferium_growth_accelerator"
  position: 7
  parent: mysticalagriculture:basics.md
item_ids:
  - mysticalagriculture:inferium_growth_accelerator
---

# Growth Accelerators

Growth Accelerators are used to increase plant growth speed. They apply random growth ticks to the first plant placed above them within the specified range. 

You can stack multiple Growth Accelerators of any tier as long as the plant is within range.

## Fabrication

The range of the Growth Accelerator is based on it being placed underneath the farmland. 

[Click here for a detailed guide on using Growth Accelerators.](https://blakesmods.com/guides/mysticalagriculture/gameplay/speeding-up-crop-growth)

<Recipe id="mysticalagriculture:inferium_growth_accelerator" />

