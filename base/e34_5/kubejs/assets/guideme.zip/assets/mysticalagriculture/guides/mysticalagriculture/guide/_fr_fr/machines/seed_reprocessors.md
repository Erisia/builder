---
navigation:
  title: "Seed Reprocessors"
  icon: "mysticalagriculture:seed_reprocessor"
  position: 202
  parent: mysticalagriculture:machines.md
item_ids:
  - mysticalagriculture:seed_reprocessor
---

# Seed Reprocessors

Seed Reprocessors are used to convert your excess seeds into their respective essences. They run off of solid fuels and have an internal power storage buffer.

## Fabrication



<Recipe id="mysticalagriculture:seed_reprocessor" />

