---
navigation:
  title: "Harvester"
  icon: "mysticalagriculture:harvester"
  position: 204
  parent: mysticalagriculture:machines.md
item_ids:
  - mysticalagriculture:harvester
---

# Harvester

Harvesters are used to automatically harvest fully grown crops. They run off of solid fuels and have an internal power storage buffer. 

The harvester will automatically re-plant the crops it harvests. 

The harvester will place all resources into it's internal inventory. If there's no space, the items will be placed on the crop.

## Crafting

The Harvester will use a bit of power every time it checks a crop for growth. Harvesting fully grown crops uses an increased amount of power. 

These machines can upgraded with [Machine Upgrades](./machine_upgrades.md). 

The Harvester can be de-activated with a Redstone signal.

<Recipe id="mysticalagriculture:harvester" />

