---
navigation:
  title: "Düngeressenz"
  icon: "mysticalagriculture:fertilized_essence"
  position: 10
  parent: mysticalagriculture:basics.md
---

# Düngeressenz

Düngeressenz **normalerweise** fällt von allen [Ressourcenpflanzen](./resource_crops.md) **außer Inferium**. Sie funktioniert identisch wie Knochenmehl, wirkt jedoch auch auf [Ressourcenpflanzen](./resource_crops.md)! 

Düngeressenz kann auch verwendet werden, um [Mystischen Dünger](../advances/mystical_fertilizer.md) effizienter herzustellen.

