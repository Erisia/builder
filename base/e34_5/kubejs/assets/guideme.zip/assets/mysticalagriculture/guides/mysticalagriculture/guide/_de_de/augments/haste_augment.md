---
navigation:
  title: "Eile-Augment"
  icon: "mysticalagriculture:haste_iii_augment"
  position: 323
  parent: mysticalagriculture:augments.md
---

# Eile-Augment

Das Eile-Augment ist ein Brustpanzer-Augment, das die Abbaugeschwindigkeit des Trägers erhöht, solange er die Rüstung trägt.

