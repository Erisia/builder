---
navigation:
  title: "Soulstone"
  icon: "mysticalagriculture:soulstone"
  position: 100
  parent: mysticalagriculture:souls.md
item_ids:
  - mysticalagriculture:soulstone
  - mysticalagriculture:soul_dust
---

# Soulstone

Soulstone is a special kind of stone that spawns in the Nether. It generates in large veins at all Y levels. 

Soulstone is a decorative block with many variants. It is also required to create [Witherproof Blocks](./witherproof_blocks.md).

It can also be smelted into Soul Dust, which has many uses as well.

<Recipe id="mysticalagriculture:soulstone_smelted" />

<Recipe id="mysticalagriculture:soul_dust_smelted" />

