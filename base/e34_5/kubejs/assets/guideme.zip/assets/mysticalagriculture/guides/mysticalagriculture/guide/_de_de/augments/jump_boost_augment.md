---
navigation:
  title: "Sprungkraft-Augment"
  icon: "mysticalagriculture:jump_boost_iii_augment"
  position: 305
  parent: mysticalagriculture:augments.md
---

# Sprungkraft-Augment

Das Sprungkraft-Augment ist ein Stiefel-Augment, das die Sprunghöhe des Trägers erhöht, während die Rüstung getragen wird.

