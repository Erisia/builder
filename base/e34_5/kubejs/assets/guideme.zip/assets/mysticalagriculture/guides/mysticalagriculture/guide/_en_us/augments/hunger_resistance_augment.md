---
navigation:
  title: "Hunger Resistance Augment"
  icon: "mysticalagriculture:hunger_resistance_augment"
  position: 318
  parent: mysticalagriculture:augments.md
---

# Hunger Resistance Augment

The Hunger Resistance Augment is a helmet augment that prevents the wearer from getting the Hunger effect while they have the armor equipped.

