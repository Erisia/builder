---
navigation:
  title: "Abbauermüdungsresistenz-Augment"
  icon: "mysticalagriculture:mining_fatigue_resistance_augment"
  position: 314
  parent: mysticalagriculture:augments.md
---

# Abbauermüdungsresistenz-Augment

Das Abbauermüdungsresistenz-Augment ist ein Rüstungs-Augment, das verhindert, dass der Träger den Effekt der Abbauermüdung erhält, solange er die Rüstung trägt.

