---
navigation:
  title: undefined
  icon: "mysticalagriculture:slowness_resistance_augment"
  position: 320
  parent: mysticalagriculture:augments.md
---

# undefined



