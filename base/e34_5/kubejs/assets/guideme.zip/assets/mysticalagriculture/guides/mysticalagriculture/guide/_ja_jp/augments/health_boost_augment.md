---
navigation:
  title: "体力増強のオーグメント"
  icon: "mysticalagriculture:health_boost_v_augment"
  position: 301
  parent: mysticalagriculture:augments.md
---

# 体力増強のオーグメント

体力増強のオーグメントは、着用者の体力をハート2-10個分増加させる防具用のオーグメントです。

