---
navigation:
  title: "Step Assist Augment"
  icon: "mysticalagriculture:step_assist_augment"
  position: 310
  parent: mysticalagriculture:augments.md
---

# Step Assist Augment

The Step Assist Augment is a leggings or boots augment that enables the wearer to walk up 1 block heights without jumping while they have the armor equipped.

