---
navigation:
  title: "Awakening Altar"
  icon: "mysticalagriculture:awakening_altar"
  position: 153
  parent: mysticalagriculture:elemental.md
item_ids:
  - mysticalagriculture:awakening_altar
  - mysticalagriculture:awakening_pedestal
  - mysticalagriculture:essence_vessel
---

# Awakening Altar

The Awakening Altar is a crafting structure that is **usually** used to create [Awakened Supremium](./awakened_supremium.md). The structure consists of 1 Infusion Altar, 4 Infusion Pedestals and 4 [Essence Vessels](./essence_vessel.md). 

Once you have a recipe put in place, you just need to activate the altar with a Redstone signal.

## Fabrication



<Recipe id="mysticalagriculture:awakening_altar" />

<Recipe id="mysticalagriculture:awakening_pedestal" />

## Fabrication

Placing the Awakening Altar in world will show you where to place your pedestals and vessels.

<Recipe id="mysticalagriculture:essence_vessel" />

