---
navigation:
  title: "Inferiumsamen"
  icon: "mysticalagriculture:inferium_seeds"
  position: 3
  parent: mysticalagriculture:basics.md
item_ids:
  - mysticalagriculture:inferium_seeds
---

# Inferiumsamen

Inferiumsamen sind eine der Hauptmethoden zur Sammlung von Inferiumessenz. Sie können auf jedem Ackerland angebaut werden, sind jedoch auf [Essenz-Ackerland](./essence_farmland.md) am effizientesten.

## Werkbank



<Recipe id="mysticalagriculture:inferium_seeds" />

