---
navigation:
  title: "Tinkering Table"
  icon: "mysticalagriculture:tinkering_table"
  position: 252
  parent: mysticalagriculture:tinkering.md
item_ids:
  - mysticalagriculture:tinkering_table
---

# Tinkering Table

The Tinkering Table is used to add [Augments](./augments.md) to [Essence Tools](./essence_tools.md) and [Essence Armor](./essence_armor.md).

## Fabrication



<Recipe id="mysticalagriculture:tinkering_table" />

