---
navigation:
  title: "Soul Jars"
  icon: "mysticalagriculture:soul_jar"
  position: 104
  parent: mysticalagriculture:souls.md
item_ids:
  - mysticalagriculture:soul_jar
---

# Soul Jars

Soul Jars are used in combination with a [Soulium Dagger](./soulium_dagger.md) to collect mob souls. Filled Soul Jars can be used to create [Resource Crops](../basics/resource_crops.md) for the corresponding entity. 

Soul Jars can also be filled using mob drops with a [Soul Extractor](../machines/soul_extractor.md).

## Crafting



<Recipe id="mysticalagriculture:soul_jar" />

