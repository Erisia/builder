---
navigation:
  title: "Seelendolch"
  icon: "mysticalagriculture:soulium_dagger"
  position: 103
  parent: mysticalagriculture:souls.md
item_ids:
  - mysticalagriculture:soulium_dagger
---

# Seelendolch

Der Seelendolch wird verwendet, um Seelen von Mobs zu sammeln. Diese Seelen werden mit [Seelengefäßen](./soul_jars.md) gesammelt. Seelen werden gesammelt, indem Mobs mit dem Seelendolch getötet werden. 

Der Seelendolch kann mit einem [Infusionsaltar](../basics/infusion_altar.md) aufgerüstet werden, um die Effizienz der Seelensammlung zu verbessern.

## Werkbank



<Recipe id="mysticalagriculture:soulium_dagger" />

<ItemImage id="mysticalagriculture:passive_soulium_dagger" />

Der Passiv abgestimmte Seelendolch bietet zusätzliche +50 Prozent gesammelte Seelen von friedlichen Mobs.

<ItemImage id="mysticalagriculture:hostile_soulium_dagger" />

Der Feindlich abgestimmte Seelendolch bietet zusätzliche +50 Prozent gesammelte Seelen von feindlichen Mobs.

