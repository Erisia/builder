---
navigation:
  title: "Nachtsicht-Augment"
  icon: "mysticalagriculture:night_vision_augment"
  position: 302
  parent: mysticalagriculture:augments.md
---

# Nachtsicht-Augment

Das Nachtsicht-Augment ist ein Helm-Augment, das dem Träger Nachtsicht gewährt, während die Rüstung getragen wird.

