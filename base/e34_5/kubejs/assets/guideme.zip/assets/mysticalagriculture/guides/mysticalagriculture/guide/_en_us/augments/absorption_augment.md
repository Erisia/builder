---
navigation:
  title: "Absorption Augment"
  icon: "mysticalagriculture:absorption_v_augment"
  position: 300
  parent: mysticalagriculture:augments.md
---

# Absorption Augment

The Absorption Augment is an armor augment that grants the user 2-10 Absorption hearts every 8 minutes while they have the armor equipped.

