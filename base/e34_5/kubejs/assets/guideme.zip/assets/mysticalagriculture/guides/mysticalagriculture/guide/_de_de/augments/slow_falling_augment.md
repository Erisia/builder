---
navigation:
  title: "Langsamer-Fall-Augment"
  icon: "mysticalagriculture:slow_falling_augment"
  position: 324
  parent: mysticalagriculture:augments.md
---

# Langsamer-Fall-Augment

Das Langsamer-Fall-Augment ist ein Hosen-Augment, das verhindert, dass der Träger den Langsamkeitseffekt erhält, solange er die Rüstung trägt. 

Dieser Effekt kann durch Halten der Umschalttaste negiert werden.

