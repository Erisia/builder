---
navigation:
  title: "Pfad-AOE-Augment"
  icon: "mysticalagriculture:pathing_aoe_iv_augment"
  position: 304
  parent: mysticalagriculture:augments.md
---

# Pfad-AOE-Augment

Das Pfad-AOE-Augment ist ein Schaufel-Augment, das den Bereich vergrößert, in dem die Schaufel Pfadblöcke erstellt, bis zu 9x9. Das AOE wird durch Schleichen während der Verwendung der Schaufel aktiviert. 

Dieser Effekt kann durch Halten der Shift-Taste negiert werden.

