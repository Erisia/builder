---
navigation:
  title: "Tinkering"
  icon: "mysticalagriculture:inferium_pickaxe"
  position: 5
---

# Tinkering

<SubPages />