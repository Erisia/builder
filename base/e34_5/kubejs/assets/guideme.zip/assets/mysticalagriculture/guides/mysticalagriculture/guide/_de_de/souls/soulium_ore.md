---
navigation:
  title: "Seelenerz"
  icon: "mysticalagriculture:soulium_ore"
  position: 101
  parent: mysticalagriculture:souls.md
---

# Seelenerz

<ItemImage id="mysticalagriculture:soulium_ore" />

Seelenerz **normalerweise** spawnt innerhalb von [Seelenstein](./soulstone.md)-Adern im Nether.

