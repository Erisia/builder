---
navigation:
  title: "Glücks-Augment"
  icon: "mysticalagriculture:luck_iii_augment"
  position: 322
  parent: mysticalagriculture:augments.md
---

# Glücks-Augment

Das Glücks-Augment ist ein Rüstungs-Augment, das die Beute aus dem Angeln oder Beutekisten für den Träger verbessert, solange er die Rüstung trägt.

