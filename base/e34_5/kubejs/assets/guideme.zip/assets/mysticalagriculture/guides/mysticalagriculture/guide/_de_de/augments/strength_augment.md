---
navigation:
  title: "Stärke-Augment"
  icon: "mysticalagriculture:strength_iii_augment"
  position: 311
  parent: mysticalagriculture:augments.md
---

# Stärke-Augment

Das Stärke-Augment ist ein Schwert-Augment, das die Menge an Schaden erhöht, die das Schwert um 5-20 verursacht.

