---
navigation:
  title: "Maschinen-Upgrades"
  icon: "mysticalagriculture:upgrade_base"
  position: 200
  parent: mysticalagriculture:machines.md
item_ids:
  - mysticalagriculture:upgrade_base
  - mysticalagriculture:inferium_upgrade
---

# Maschinen-Upgrades

Maschinen-Upgrades können in anwendbare Maschinen eingesetzt werden, um deren Effektivität zu erhöhen. 

Höherstufige Maschinen verbrauchen und erzeugen schneller Energie.

## Werkbank



<Recipe id="mysticalagriculture:upgrade_base" />

<Recipe id="mysticalagriculture:inferium_upgrade" />

