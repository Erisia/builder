---
navigation:
  title: "Essenzrüstungen"
  icon: "mysticalagriculture:inferium_chestplate"
  position: 251
  parent: mysticalagriculture:tinkering.md
item_ids:
  - mysticalagriculture:inferium_chestplate
---

# Essenzrüstungen

Das Aufrüsten der Diamant*-Rüstungen mit Essenzen verbessert deren Haltbarkeit und Schutz. Dies ermöglicht auch die Ausrüstung mit [Augments](./augments.md). 

Essenzrüstungen können in einem Amboss mit ihrem entsprechenden Essenzbarren repariert werden. Diese Rüstungsteile haben jeweils 1 Augment-Slot.

## Werkbank



<Recipe id="mysticalagriculture:gear/inferium_chestplate" />

