---
navigation:
  title: "Jump Boost Augment"
  icon: "mysticalagriculture:jump_boost_iii_augment"
  position: 305
  parent: mysticalagriculture:augments.md
---

# Jump Boost Augment

The Jump Boost Augment is a boots augment that increases the wearers jump height while they have the armor equipped.

