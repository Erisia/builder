---
navigation:
  title: "Fire Resistance Augment"
  icon: "mysticalagriculture:fire_resistance_augment"
  position: 309
  parent: mysticalagriculture:augments.md
---

# Fire Resistance Augment

The Fire Resistance Augment is an armor augment that grants the wearer Fire Resistance while they have the armor equipped.

