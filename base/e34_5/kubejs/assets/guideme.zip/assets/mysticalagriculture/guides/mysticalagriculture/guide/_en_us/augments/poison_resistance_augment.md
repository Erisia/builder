---
navigation:
  title: "Poison Resistance Augment"
  icon: "mysticalagriculture:poison_resistance_augment"
  position: 313
  parent: mysticalagriculture:augments.md
---

# Poison Resistance Augment

The Poison Resistance Augment is an armor augment that prevents the wearer from getting the poisoned while they have the armor equipped.

