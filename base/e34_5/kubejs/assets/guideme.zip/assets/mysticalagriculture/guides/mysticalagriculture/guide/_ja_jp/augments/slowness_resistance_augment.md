---
navigation:
  title: "移動速度低下耐性のオーグメント"
  icon: "mysticalagriculture:slowness_resistance_augment"
  position: 320
  parent: mysticalagriculture:augments.md
---

# 移動速度低下耐性のオーグメント

移動速度低下耐性のオーグメントは、着用者の移動速度低下の効果を防ぐレギンス用のオーグメントです。

