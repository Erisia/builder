---
navigation:
  title: "Mystical Fertilizer"
  icon: "mysticalagriculture:mystical_fertilizer"
  position: 50
  parent: mysticalagriculture:advances.md
item_ids:
  - mysticalagriculture:mystical_fertilizer
---

# Mystical Fertilizer

Mystical Fertilizer is used to instantly grow a crop or sapling. It's effective on [Resource Crops](../basics/resource_crops.md) too!

## Crafting



<Recipe id="mysticalagriculture:mystical_fertilizer" />

<Recipe id="mysticalagriculture:mystical_fertilizer_better" />

