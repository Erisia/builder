---
navigation:
  title: "落下速度低下のオーグメント"
  icon: "mysticalagriculture:slow_falling_augment"
  position: 324
  parent: mysticalagriculture:augments.md
---

# 落下速度低下のオーグメント

落下速度低下のオーグメントは、着用者に落下速度低下を付与するブーツ用のオーグメントです。

この効果はShiftキーを押している間は無効化されます。

