---
navigation:
  title: "Augments"
  icon: "mysticalagriculture:unattuned_augment"
  position: 253
  parent: mysticalagriculture:tinkering.md
item_ids:
  - mysticalagriculture:unattuned_augment
---

# Augments

Augments are upgrades for [Essence Tools](./essence_tools.md) and [Essence Armor](./essence_armor.md). You add Augments to your gear using a [Tinkering Table](./tinkering_table.md). 

Each Augment has a tier assigned to it, designating the minimum tier of gear piece required to equip it. 

## Crafting

You can see what each Augment does in the 'Augments' section of this guide.

<Recipe id="mysticalagriculture:unattuned_augment" />

