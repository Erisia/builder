---
navigation:
  title: "Seelenextraktor"
  icon: "mysticalagriculture:soul_extractor"
  position: 203
  parent: mysticalagriculture:machines.md
item_ids:
  - mysticalagriculture:soul_extractor
---

# Seelenextraktor

Seelenextraktoren werden verwendet, um Mob-Drops in Mob-Seelen umzuwandeln. Sie laufen mit festen Brennstoffen und haben einen internen Energiespeicher. 

Der Seelenextraktor bietet eine Verwendung für überschüssige Mob-Drops, ist jedoch in der Regel nicht so effizient wie die Verwendung eines [Seelendolchs](../souls/soulium_dagger.md).

## Werkbank



<Recipe id="mysticalagriculture:soul_extractor" />

