---
navigation:
  title: "Infusion Altar"
  icon: "mysticalagriculture:infusion_altar"
  position: 9
  parent: mysticalagriculture:basics.md
item_ids:
  - mysticalagriculture:infusion_altar
  - mysticalagriculture:infusion_pedestal
---

# Infusion Altar

The Infusion Altar is a crafting structure that is **usually** used to create Mystical Agriculture seeds. The structure consists of 1 Infusion Altar and 8 Infusion Pedestals. 

Once you have a recipe put in place, you just need to activate the altar with a Wand or Redstone signal.

## Crafting



<Recipe id="mysticalagriculture:infusion_altar" />

<Recipe id="mysticalagriculture:infusion_pedestal" />

Placing the Infusion Altar in world will show you where to place your pedestals. 

[Click here for a detailed guide on using the Infusion Altar.](https://blakesmods.com/wiki/mysticalagriculture/guides/creating-seeds)

