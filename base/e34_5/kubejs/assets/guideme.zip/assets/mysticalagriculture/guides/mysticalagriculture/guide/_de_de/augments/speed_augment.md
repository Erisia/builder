---
navigation:
  title: "Geschwindigkeits-Augment"
  icon: "mysticalagriculture:speed_iii_augment"
  position: 306
  parent: mysticalagriculture:augments.md
---

# Geschwindigkeits-Augment

Das Geschwindigkeits-Augment ist ein Beinrüstungs-Augment, das die Bewegungsgeschwindigkeit des Trägers erhöht, während die Rüstung getragen wird. Dieser Effekt wird auch auf die Fluggeschwindigkeit angewendet.

