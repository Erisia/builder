---
navigation:
  title: "Sensen"
  icon: "mysticalagriculture:inferium_scythe"
  position: 54
  parent: mysticalagriculture:advances.md
item_ids:
  - mysticalagriculture:diamond_scythe
  - mysticalagriculture:inferium_scythe
---

# Sensen

Sensen werden zum Ernten großer Mengen von Pflanzen durch Rechtsklick verwendet. Alle vollständig gewachsenen Pflanzen im Wirkungsbereich werden geerntet, ohne entwurzelt zu werden. 

Sensen sind auch eine effektive Waffe mit einem erhöhten Angriffs-AOE. 

Höherstufige Sensen haben einen größeren Wirkungsbereich.

## Werkbank



<Recipe id="mysticalagriculture:diamond_scythe" />

<Recipe id="mysticalagriculture:gear/inferium_scythe" />

