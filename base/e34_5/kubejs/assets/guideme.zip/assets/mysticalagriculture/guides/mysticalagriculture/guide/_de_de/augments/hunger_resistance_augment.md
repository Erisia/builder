---
navigation:
  title: "Hungerresistenz-Augment"
  icon: "mysticalagriculture:hunger_resistance_augment"
  position: 318
  parent: mysticalagriculture:augments.md
---

# Hungerresistenz-Augment

Das Hungerresistenz-Augment ist ein Helm-Augment, das verhindert, dass der Träger den Hungereffekt erhält, solange er die Rüstung trägt.

