---
navigation:
  title: "Essence Vessel"
  icon: "mysticalagriculture:essence_vessel"
  position: 152
  parent: mysticalagriculture:elemental.md
item_ids:
  - mysticalagriculture:essence_vessel
---

# Essence Vessel

Essence Vessels are used in the [Awakening Altar](./awakening_altar.md) structure to hold the elemental essences required to create items. Each vessel can hold up to 40 of a single elemental essence.

## Fabrication



<Recipe id="mysticalagriculture:essence_vessel" />

