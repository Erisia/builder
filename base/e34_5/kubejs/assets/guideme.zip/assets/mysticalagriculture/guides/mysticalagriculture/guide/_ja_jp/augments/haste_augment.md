---
navigation:
  title: "採掘速度上昇のオーグメント"
  icon: "mysticalagriculture:haste_iii_augment"
  position: 323
  parent: mysticalagriculture:augments.md
---

# 採掘速度上昇のオーグメント

採掘速度上昇のオーグメントは、着用者の採掘速度を増加させるチェストプレート用のオーグメントです。

