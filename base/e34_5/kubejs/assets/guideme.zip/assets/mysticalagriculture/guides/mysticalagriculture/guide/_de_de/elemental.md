---
navigation:
  title: "Elementar"
  icon: "mysticalagriculture:inferium_staff"
  position: 3
---

# Elementar

<SubPages />