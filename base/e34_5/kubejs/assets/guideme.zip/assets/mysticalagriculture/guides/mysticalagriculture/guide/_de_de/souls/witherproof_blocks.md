---
navigation:
  title: "Witherfeste Blöcke"
  icon: "mysticalagriculture:witherproof_block"
  position: 102
  parent: mysticalagriculture:souls.md
item_ids:
  - mysticalagriculture:witherproof_block
  - mysticalagriculture:witherproof_glass
---

# Witherfeste Blöcke

Witherfeste Blöcke sind unzerstörbar durch den Wither. Sehr nützlich für diejenigen, die Bosse austricksen möchten. 

Sie sind auch immun gegen Schaden durch den Enderdrachen, jedoch kann dieser immer noch durch sie hindurchfliegen.

## Werkbank



<Recipe id="mysticalagriculture:witherproof_block" />

<Recipe id="mysticalagriculture:witherproof_glass" />

