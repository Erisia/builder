---
navigation:
  title: "Enchanter"
  icon: "mysticalagriculture:enchanter"
  position: 110
  parent: mysticalagriculture:souls.md
item_ids:
  - mysticalagriculture:enchanter
---

# Enchanter

The Enchanter is a block that allows you to enchant your tools and armor using different crafting materials and Experience Essence. 

The Enchanter can apply enchantments to both Books and tools/armor, similarly to an Anvil.

## Crafting



<Recipe id="mysticalagriculture:enchanter" />

