---
navigation:
  title: "Slow Falling Augment"
  icon: "mysticalagriculture:slow_falling_augment"
  position: 324
  parent: mysticalagriculture:augments.md
---

# Slow Falling Augment

The Slow Falling Augment is a leggings augment that prevents the wearer from getting the Slowness effect while they have the armor equipped. 

This effect can be negated by holding down the Shift key.

