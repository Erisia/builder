---
navigation:
  title: "Health Boost Augment"
  icon: "mysticalagriculture:health_boost_v_augment"
  position: 301
  parent: mysticalagriculture:augments.md
---

# Health Boost Augment

The Health Boost Augment is an armor augment that adds 2-10 hearts to the wearer while they have the armor equipped.

