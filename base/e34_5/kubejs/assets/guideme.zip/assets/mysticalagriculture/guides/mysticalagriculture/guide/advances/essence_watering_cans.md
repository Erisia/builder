---
navigation:
  title: "Essence Watering Cans"
  icon: "mysticalagriculture:inferium_watering_can"
  position: 52
  parent: mysticalagriculture:advances.md
item_ids:
  - mysticalagriculture:inferium_watering_can
---

# Essence Watering Cans

Upgrading the regular [Watering Can](../basics/watering_can.md) with essences and [Mystical Fertilizer](./mystical_fertilizer.md) improves your farming experience a ton. 

Upgraded Watering Cans have improved range and growth acceleration speed. You can also toggle automatic watering by Shift + Right Clicking with the Watering Can while not targeting a block.

## Crafting



<Recipe id="mysticalagriculture:gear/inferium_watering_can" />

