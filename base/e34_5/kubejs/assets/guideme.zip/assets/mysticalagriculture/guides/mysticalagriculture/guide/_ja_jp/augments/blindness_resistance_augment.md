---
navigation:
  title: "盲目耐性のオーグメント"
  icon: "mysticalagriculture:blindness_resistance_augment"
  position: 317
  parent: mysticalagriculture:augments.md
---

# 盲目耐性のオーグメント

盲目耐性のオーグメントは、着用者の盲目の効果を防ぐヘルメット用のオーグメントです。

