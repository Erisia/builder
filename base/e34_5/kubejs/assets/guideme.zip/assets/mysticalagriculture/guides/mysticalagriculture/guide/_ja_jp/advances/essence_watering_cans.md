---
navigation:
  title: "エッセンスのジョウロ"
  icon: "mysticalagriculture:inferium_watering_can"
  position: 52
  parent: mysticalagriculture:advances.md
item_ids:
  - mysticalagriculture:inferium_watering_can
---

# エッセンスのジョウロ

通常の[ジョウロ](../basics/watering_can.md)を、エッセンスと[神秘の肥料](./mystical_fertilizer.md)で強化すると、農業体験が大幅に向上します。

強化されたジョウロは、範囲と成長促進速度が向上します。

ブロックをターゲットしていないときにShift+右クリックでジョウロの自動散水を切り替えることもできます。

## クラフト



<Recipe id="mysticalagriculture:gear/inferium_watering_can" />

