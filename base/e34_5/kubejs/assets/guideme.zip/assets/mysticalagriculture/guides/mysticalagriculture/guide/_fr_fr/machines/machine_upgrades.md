---
navigation:
  title: "Machine Upgrades"
  icon: "mysticalagriculture:upgrade_base"
  position: 200
  parent: mysticalagriculture:machines.md
item_ids:
  - mysticalagriculture:upgrade_base
  - mysticalagriculture:inferium_upgrade
---

# Machine Upgrades

Machine Upgrades can be placed in applicable machines to increase their effectiveness. 

Higher tier machines will both use and generate power faster.

## Fabrication



<Recipe id="mysticalagriculture:upgrade_base" />

<Recipe id="mysticalagriculture:inferium_upgrade" />

