---
navigation:
  title: "Basics"
  icon: "mysticalagriculture:inferium_essence"
---

# Basics

<SubPages />