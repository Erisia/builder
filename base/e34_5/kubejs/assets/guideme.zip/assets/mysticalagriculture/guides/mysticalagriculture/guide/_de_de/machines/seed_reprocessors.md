---
navigation:
  title: "Samenverarbeiter"
  icon: "mysticalagriculture:seed_reprocessor"
  position: 202
  parent: mysticalagriculture:machines.md
item_ids:
  - mysticalagriculture:seed_reprocessor
---

# Samenverarbeiter

Samenverarbeiter werden verwendet, um überschüssige Samen in ihre jeweiligen Essenzen umzuwandeln. Sie laufen mit festen Brennstoffen und haben einen internen Energiespeicher.

## Werkbank



<Recipe id="mysticalagriculture:seed_reprocessor" />

