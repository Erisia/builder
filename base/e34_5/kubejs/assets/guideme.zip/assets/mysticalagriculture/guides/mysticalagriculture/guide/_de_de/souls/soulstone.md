---
navigation:
  title: "Seelenstein"
  icon: "mysticalagriculture:soulstone"
  position: 100
  parent: mysticalagriculture:souls.md
item_ids:
  - mysticalagriculture:soulstone
  - mysticalagriculture:soul_dust
---

# Seelenstein

Seelenstein ist eine besondere Art von Stein, die im Nether vorkommt. Es entsteht in großen Adern auf allen Y-Ebenen. 

Seelenstein ist ein dekorativer Block mit vielen Varianten. Es wird auch benötigt, um [Witherfeste Blöcke](./witherproof_blocks.md) herzustellen.

Es kann auch zu Seelenstaub geschmolzen werden, der ebenfalls viele Verwendungen hat.

<Recipe id="mysticalagriculture:soulstone_smelted" />

<Recipe id="mysticalagriculture:soul_dust_smelted" />

