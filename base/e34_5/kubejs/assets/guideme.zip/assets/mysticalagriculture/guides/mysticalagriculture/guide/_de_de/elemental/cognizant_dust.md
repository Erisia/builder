---
navigation:
  title: "Erkenntnisstaub"
  icon: "mysticalagriculture:cognizant_dust"
  position: 151
  parent: mysticalagriculture:elemental.md
---

# Erkenntnisstaub

Erkenntnisstaub wird **normalerweise** durch das Töten eines Withers oder Enderdrachens mit einer [Essenzwaffe](../tinkering/essence_tools.md) erhalten, die mit Mystischer Erleuchtung verzaubert ist. 

Höhere Stufen der Mystischen Erleuchtung erhöhen die Menge des beim Töten fallenden Staubs.

