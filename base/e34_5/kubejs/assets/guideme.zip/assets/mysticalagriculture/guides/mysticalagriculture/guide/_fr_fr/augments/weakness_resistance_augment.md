---
navigation:
  title: undefined
  icon: "mysticalagriculture:weakness_resistance_augment"
  position: 321
  parent: mysticalagriculture:augments.md
---

# undefined



