---
navigation:
  title: "Prosperity Shards"
  icon: "mysticalagriculture:prosperity_shard"
  position: 1
  parent: mysticalagriculture:basics.md
---

# Prosperity Shards

Prosperity Shards are the other of the two base materials in Mystical Agriculture. They are used to create magical variations of basic materials. You can **usually** obtain Prosperity Shards by mining them from the ground.

