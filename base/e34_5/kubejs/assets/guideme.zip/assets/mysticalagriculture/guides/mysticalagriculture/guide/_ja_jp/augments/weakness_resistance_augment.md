---
navigation:
  title: "弱体化耐性のオーグメント"
  icon: "mysticalagriculture:weakness_resistance_augment"
  position: 321
  parent: mysticalagriculture:augments.md
---

# 弱体化耐性のオーグメント

弱体化耐性のオーグメントは、着用者の弱体化の効果を防ぐチェストプレート用のオーグメントです。

