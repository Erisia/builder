---
navigation:
  title: undefined
  icon: "mysticalagriculture:nausea_resistance_augment"
  position: 319
  parent: mysticalagriculture:augments.md
---

# undefined



