---
navigation:
  title: "Augmentierungen"
  icon: "mysticalagriculture:unattuned_augment"
  position: 253
  parent: mysticalagriculture:tinkering.md
item_ids:
  - mysticalagriculture:unattuned_augment
---

# Augmentierungen

Augmentierungen sind Upgrades für [Essenzwerkzeuge](./essence_tools.md) und [Essenzrüstungen](./essence_armor.md). Augmentierungen werden mit einem [Basteltisch](./tinkering_table.md) zu den Ausrüstungsgegenständen hinzugefügt. 

Jedes Augment hat eine Stufe, die die Mindeststufe des Ausrüstungsgegenstands angibt, die erforderlich ist, um es auszurüsten.

## Werkbank

Die Funktion jeder Augmentierung sind im Abschnitt 'Augmentierungen' dieses Leitfadens aufgeführt.

<Recipe id="mysticalagriculture:unattuned_augment" />

