---
navigation:
  title: "Sicheln"
  icon: "mysticalagriculture:inferium_sickle"
  position: 53
  parent: mysticalagriculture:advances.md
item_ids:
  - mysticalagriculture:diamond_sickle
  - mysticalagriculture:inferium_sickle
---

# Sicheln

Sicheln werden zum Ernten/Zerstören großer Mengen von Pflanzenmaterial verwendet. 

Höherstufige Sicheln haben einen größeren Wirkungsbereich.

## Werkbank



<Recipe id="mysticalagriculture:diamond_sickle" />

<Recipe id="mysticalagriculture:gear/inferium_sickle" />

