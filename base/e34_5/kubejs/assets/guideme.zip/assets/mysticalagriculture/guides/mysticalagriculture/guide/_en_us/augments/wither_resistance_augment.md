---
navigation:
  title: "Wither Resistance Augment"
  icon: "mysticalagriculture:wither_resistance_augment"
  position: 315
  parent: mysticalagriculture:augments.md
---

# Wither Resistance Augment

The Wither Resistance Augment is an armor augment that prevents the wearer from getting the Wither effect while they have the armor equipped.

