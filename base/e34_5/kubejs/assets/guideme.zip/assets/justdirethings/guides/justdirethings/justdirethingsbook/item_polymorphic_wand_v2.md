---
navigation:
  title: "Adv. Polymorphic Wand"
  icon: "justdirethings:polymorphic_wand_v2"
  position: 22
  parent: justdirethings:items.md
item_ids:
  - justdirethings:polymorphic_wand_v2
---

# Adv. Polymorphic Wand

The advanced polymorphic wand is an upgrade to the Polymorphic Wand. The existing 'random polymorph' ability still exists, but a new ability, 'targetted polymorph' is now available!

Simply shift-right click on any mob to save that type of mob to the wand, then activate the targeted polymorph ability to convert any mob to that type automatically!

Some mobs cannot be saved to the wand (You can edit these with Tags).

It is recommended to set the two abilities to different clicks or hotkeys.

## Adv. Polymorphic Wand



<Recipe id="justdirethings:polymorphic_wand_v2" />

