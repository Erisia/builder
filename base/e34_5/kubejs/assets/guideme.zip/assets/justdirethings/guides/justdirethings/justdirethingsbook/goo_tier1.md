---
navigation:
  title: "Primogel Goo"
  icon: "justdirethings:gooblock_tier1"
  position: 1
  parent: justdirethings:goo.md
item_ids:
  - justdirethings:gooblock_tier1
---

# Primogel Goo

Primogel Goo, the foundational tier of goo, can transform basic resources like Iron into Ferricore. It is perfect for initial experiments in material transformation and enhancing common materials into something more useful and efficient.

Crafted from simple Overworld materials, Primogel Goo is the first step in exploring the alchemical potential of goo.

## Crafting Primogel Goo



<Recipe id="justdirethings:gooblock_tier1" />

