---
navigation:
  title: "Celestigem Hoe"
  icon: "justdirethings:celestigem_hoe[justdirethings:forge_energy=10000]"
  position: 17
  parent: justdirethings:tools.md
item_ids:
  - justdirethings:celestigem_hoe
---

# Celestigem Hoe

Upgraded from [Blazegold Hoe](./tool_blazegold_hoe.md), Celestigem tools have Forge Energy instead of durability. This hoe creates Voidshimmer soil.

If the hoe has 'teleport drops' ability, and is bound to an inventory, the soil will teleport the autoharvested blocks to that inventory.

Celestigem Hoe Crafting

<Recipe id="justdirethings:celestigem_hoe" />

