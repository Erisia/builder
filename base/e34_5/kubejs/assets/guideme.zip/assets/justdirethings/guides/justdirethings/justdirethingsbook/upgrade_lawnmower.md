---
navigation:
  title: "Lawn Mower"
  icon: "justdirethings:upgrade_lawnmower"
  position: 1
  parent: justdirethings:upgrades.md
item_ids:
  - justdirethings:upgrade_lawnmower
---

# Lawn Mower

The Lawn Mower upgrade is an activated ability which can be installed on shovels starting at ferricore. When you activate it, all nearby grass and flowers will be cut down, and their items will be dropped on the ground.

## Lawn Mower Upgrade Crafting



<Recipe id="justdirethings:upgrade_lawnmower" />

