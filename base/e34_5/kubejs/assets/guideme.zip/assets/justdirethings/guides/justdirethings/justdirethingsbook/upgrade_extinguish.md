---
navigation:
  title: "Extinguish"
  icon: "justdirethings:upgrade_extinguish"
  position: 1
  parent: justdirethings:upgrades.md
item_ids:
  - justdirethings:upgrade_extinguish
---

# Extinguish

Protect yourself from fiery danger with the Extinguish upgrade. This handy upgrade automatically extinguishes fire on the player, ensuring safety from sudden blazes.

Note: There is a cooldown before it can extinguish you again. This cooldown is shorter at higher tiers of armor.

## Extinguish Upgrade Crafting



<Recipe id="justdirethings:upgrade_extinguish" />

