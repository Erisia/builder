---
navigation:
  title: "Yondu Arrow"
  icon: "justdirethings:upgrade_epicarrow"
  position: 1
  parent: justdirethings:upgrades.md
item_ids:
  - justdirethings:upgrade_epicarrow
---

# Yondu Arrow

The Yondu Arrow upgrade enables your arrows to seek out targets, chaining damage across multiple enemies. Ideal for crowd control.

This is an activated ability. Once activated, the next arrow you fire will chain from one mob to the next, up to 10 times!

## Epic Arrow Crafting



<Recipe id="justdirethings:upgrade_epicarrow" />

