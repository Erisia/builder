---
navigation:
  title: "Phase"
  icon: "justdirethings:upgrade_phase"
  position: 1
  parent: justdirethings:upgrades.md
item_ids:
  - justdirethings:upgrade_phase
---

# Phase

The Phase upgrade allows you to pass through walls and obstacles. Activate it to become ethereal, ignoring all physical barriers except the floor.

This allows you to walk through walls while active. Some blocks may still be solid, such as bedrock and any blocks mod pack makers specify.

## Phase Crafting



<Recipe id="justdirethings:upgrade_phase" />

