---
navigation:
  title: "Step Height"
  icon: "justdirethings:upgrade_stepheight"
  position: 1
  parent: justdirethings:upgrades.md
item_ids:
  - justdirethings:upgrade_stepheight
---

# Step Height

The Step Height upgrade allows you to effortlessly step up full blocks without jumping. Navigate terrain smoothly and maintain your pace without interruption.

## Step Height Upgrade Crafting



<Recipe id="justdirethings:upgrade_stepheight" />

