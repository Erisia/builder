---
navigation:
  title: "Eclipse Alloy Helmet"
  icon: "justdirethings:eclipsealloy_helmet[justdirethings:forge_energy=500000]"
  position: 20
  parent: justdirethings:armor.md
item_ids:
  - justdirethings:eclipsealloy_helmet
---

# Eclipse Alloy Helmet

The Eclipse Alloy Helmet is the pinnacle of armor technology, using Forge Energy with a large capacity of 500,000 FE. Remember to keep it charged, ideally with a [Pocket Generator](./item_pocket_generator.md), to utilize its full potential.

## Eclipse Alloy Helmet Crafting



<Recipe id="justdirethings:eclipsealloy_helmet" />

