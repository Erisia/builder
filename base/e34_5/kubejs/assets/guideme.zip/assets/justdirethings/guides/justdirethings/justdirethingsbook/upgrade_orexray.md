---
navigation:
  title: "Ore X-Ray"
  icon: "justdirethings:upgrade_orexray"
  position: 1
  parent: justdirethings:upgrades.md
item_ids:
  - justdirethings:upgrade_orexray
---

# Ore X-Ray

Discover hidden riches with the Ore X-Ray upgrade. This powerful tool allows you to see through solid blocks, revealing valuable ores hidden away in the stone.

This upgrade replaces the ore scanner upgrade, and is activated in the same way.

## Ore X-Ray Crafting



<Recipe id="justdirethings:upgrade_orexray" />

