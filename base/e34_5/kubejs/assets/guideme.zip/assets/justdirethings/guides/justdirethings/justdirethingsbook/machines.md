---
navigation:
  title: "Machines"
  icon: "justdirethings:blockbreakert1"
  position: 2
---

# Machines

<SubPages />