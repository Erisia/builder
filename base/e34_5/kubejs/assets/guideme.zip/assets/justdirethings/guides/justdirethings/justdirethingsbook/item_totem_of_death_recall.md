---
navigation:
  title: "Totem of Death Recall"
  icon: "justdirethings:totem_of_death_recall"
  position: 4
  parent: justdirethings:items.md
item_ids:
  - justdirethings:totem_of_death_recall
---

# Totem of Death Recall

The Totem of Death Recall provides a second chance after a fatal mistake. Keep it in your inventory, and it will automatically activate on death, binding itself to the position you died at.

Hold Right-click the activated totem to teleport back to your death point. The totem is consumed upon use.

## Totem of Death Recall Crafting



<Recipe id="justdirethings:totem_of_death_recall" />

