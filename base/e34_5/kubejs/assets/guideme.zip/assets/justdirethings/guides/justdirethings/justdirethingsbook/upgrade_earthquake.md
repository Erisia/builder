---
navigation:
  title: "Earthquake"
  icon: "justdirethings:upgrade_earthquake"
  position: 1
  parent: justdirethings:upgrades.md
item_ids:
  - justdirethings:upgrade_earthquake
---

# Earthquake

Unleash the force of nature with the Earthquake upgrade. This upgrade causes a powerful tremor around you, slowing all nearby enemies.

It must be activated with a bound hotkey configured in the tool settings menu

## Earthquake Crafting



<Recipe id="justdirethings:upgrade_earthquake" />

