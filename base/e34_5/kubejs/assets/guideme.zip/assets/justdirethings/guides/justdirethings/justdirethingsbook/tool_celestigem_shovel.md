---
navigation:
  title: "Celestigem Shovel"
  icon: "justdirethings:celestigem_shovel[justdirethings:forge_energy=10000]"
  position: 15
  parent: justdirethings:tools.md
item_ids:
  - justdirethings:celestigem_shovel
---

# Celestigem Shovel

Building upon [Blazegold Shovel](./tool_blazegold_shovel.md), this shovel operates on Forge Energy. Equipped with a 10,000 FE capacity, keep it powered using a [Pocket Generator](./item_pocket_generator.md).

Celestigem Shovel Crafting

<Recipe id="justdirethings:celestigem_shovel" />

