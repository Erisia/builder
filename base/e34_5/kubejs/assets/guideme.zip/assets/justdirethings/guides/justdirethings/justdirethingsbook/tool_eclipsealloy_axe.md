---
navigation:
  title: "Eclipse Alloy Axe"
  icon: "justdirethings:eclipsealloy_axe[justdirethings:forge_energy=500000]"
  position: 23
  parent: justdirethings:tools.md
item_ids:
  - justdirethings:eclipsealloy_axe
---

# Eclipse Alloy Axe

This Eclipse Alloy Axe excels in woodcutting with high efficiency and increased energy storage. 

It's engineered for enduring the most demanding lumber tasks.

Eclipse Alloy Axe Crafting

<Recipe id="justdirethings:eclipsealloy_axe" />

