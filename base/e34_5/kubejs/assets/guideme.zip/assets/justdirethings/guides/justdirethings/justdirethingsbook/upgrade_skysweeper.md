---
navigation:
  title: "Sky Sweeper"
  icon: "justdirethings:upgrade_skysweeper"
  position: 1
  parent: justdirethings:upgrades.md
item_ids:
  - justdirethings:upgrade_skysweeper
---

# Sky Sweeper

The sky sweeper is a passive ability installed on Ferricore shovels, and above. When you break a block with gravity (like gravel or sand), any matching blocks above that one will also be broken automatically.  No more falling gravel while mining!

## Sky Sweeper Upgrade Crafting



<Recipe id="justdirethings:upgrade_skysweeper" />

