---
navigation:
  title: "Ground Stomp"
  icon: "justdirethings:upgrade_groundstomp"
  position: 1
  parent: justdirethings:upgrades.md
item_ids:
  - justdirethings:upgrade_groundstomp
---

# Ground Stomp

Unleash seismic force with the Ground Stomp upgrade. When activated, this upgrade creates a shockwave that knocks back nearby entities.

This is an activated ability, so you'll need to assign a hotkey to use it.

## Ground Stomp Upgrade Crafting



<Recipe id="justdirethings:upgrade_groundstomp" />

