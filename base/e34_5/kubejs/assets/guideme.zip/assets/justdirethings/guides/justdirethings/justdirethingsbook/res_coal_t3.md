---
navigation:
  title: "Voidflame Coal"
  icon: "justdirethings:coal_t3"
  position: 23
  parent: justdirethings:resources.md
---

# Voidflame Coal

Voidflame Coal is obtained by placing a block of [Blaze Ember](./res_coal_t2.md) next to a [VoidShimmer Goo](./goo_tier3.md). This coal variant has mystical properties, enhancing its energy output.

