---
navigation:
  title: "Blazegold Bow"
  icon: "justdirethings:bow_blazegold"
  position: 12
  parent: justdirethings:tools.md
item_ids:
  - justdirethings:bow_blazegold
---

# Blazegold Bow

Stronger than the [Ferricore Bow](./tool_ferricore_bow.md). Features 'Lava Repair'.

In addition, it has 2 slots for [Potion Canister](./item_potion_canister.md)

Blazegold Bow Crafting

<Recipe id="justdirethings:bow_blazegold" />

