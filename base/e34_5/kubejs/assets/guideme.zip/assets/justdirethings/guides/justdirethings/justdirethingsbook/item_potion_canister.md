---
navigation:
  title: "Potion Canister"
  icon: "justdirethings:potion_canister"
  position: 20
  parent: justdirethings:items.md
---

# Potion Canister

The Potion Canister can be right-clicked to open a UI where you can insert potion bottles. These will fill the canister's internal fluid holder. 

 This canister can be slotted into bows, and the potion effects will apply to the arrows you shoot.

Ensure that the bow has the appropriate upgrade(s) installed to take advantage of this canister.

 Ensure that the canister is slotted into the appropriate slot within the bow's tool settings.

