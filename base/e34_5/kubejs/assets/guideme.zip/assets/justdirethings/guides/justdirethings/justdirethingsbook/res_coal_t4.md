---
navigation:
  title: "Eclipse Ember"
  icon: "justdirethings:coal_t4"
  position: 24
  parent: justdirethings:resources.md
---

# Eclipse Ember

Eclipse Ember is the final evolution of specialized coal, crafted by placing a block of [Voidflame Coal](./res_coal_t3.md) next to a [Shadowpulse Goo](./goo_tier4.md). It offers the highest energy density among coal types.

