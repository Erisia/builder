---
navigation:
  title: "Blazegold Shovel"
  icon: "justdirethings:blazegold_shovel"
  position: 9
  parent: justdirethings:tools.md
item_ids:
  - justdirethings:blazegold_shovel
---

# Blazegold Shovel

This shovel digs faster than the [Ferricore Shovel](./tool_ferricore_shovel.md). It repairs itself when dropped into lava via 'Lava Repair'.

Blazegold Shovel Crafting

<Recipe id="justdirethings:blazegold_shovel" />

