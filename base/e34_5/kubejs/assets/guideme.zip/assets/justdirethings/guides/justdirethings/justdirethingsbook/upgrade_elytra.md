---
navigation:
  title: "Elytra"
  icon: "justdirethings:upgrade_elytra"
  position: 1
  parent: justdirethings:upgrades.md
item_ids:
  - justdirethings:upgrade_elytra
---

# Elytra

Soar through the skies with the Elytra upgrade. This upgrade equips your armor with elytra wings, enabling flight when falling.

## Elytra Upgrade Crafting



<Recipe id="justdirethings:upgrade_elytra" />

