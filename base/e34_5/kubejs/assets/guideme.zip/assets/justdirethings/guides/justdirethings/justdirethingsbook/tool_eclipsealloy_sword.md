---
navigation:
  title: "Eclipse Alloy Sword"
  icon: "justdirethings:eclipsealloy_sword[justdirethings:forge_energy=500000]"
  position: 20
  parent: justdirethings:tools.md
item_ids:
  - justdirethings:eclipsealloy_sword
---

# Eclipse Alloy Sword

The Eclipse Alloy Sword is the pinnacle of combat technology in Just Dire Things, featuring a large energy capacity capable of supporting the most advanced upgrades. 

Forged from Eclipse Alloy, this end-tier tool offers exceptional damage and durability, and is ideal for the most lethal offensive abilities.

Eclipse Alloy Sword Crafting

<Recipe id="justdirethings:eclipsealloy_sword" />

