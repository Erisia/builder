---
navigation:
  title: "Blazegold Pickaxe"
  icon: "justdirethings:blazegold_pickaxe"
  position: 8
  parent: justdirethings:tools.md
item_ids:
  - justdirethings:blazegold_pickaxe
---

# Blazegold Pickaxe

Faster than the [Ferricore Pickaxe](./tool_ferricore_pickaxe.md) and includes 'Lava Repair'—repairs itself when dropped into lava.

Blazegold Pickaxe Crafting

<Recipe id="justdirethings:blazegold_pickaxe" />

