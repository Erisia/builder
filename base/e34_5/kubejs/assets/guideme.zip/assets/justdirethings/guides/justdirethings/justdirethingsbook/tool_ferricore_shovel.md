---
navigation:
  title: "Ferricore Shovel"
  icon: "justdirethings:ferricore_shovel"
  position: 3
  parent: justdirethings:tools.md
item_ids:
  - justdirethings:ferricore_shovel
---

# Ferricore Shovel

Crafted from durable Ferricore, this shovel is ideal for digging through dirt, sand, and gravel. It offers improved performance over iron shovels and can be upgraded with various abilities.

Ferricore Shovel Crafting

<Recipe id="justdirethings:ferricore_shovel" />

