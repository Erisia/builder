---
navigation:
  title: "Raw Ferricore Block"
  icon: "justdirethings:raw_ferricore_ore"
  parent: justdirethings:resources.md
---

# Raw Ferricore Block

When an Iron Block is consumed by Primogel Goo, it transforms into a Raw Ferricore Block. Mine this block to obtain Raw Ferricore items, which can be smelted into [Ferricore Ingots](./res_ferricore.md).

<ItemImage id="justdirethings:raw_ferricore" />

Raw Ferricore drops when you break the Raw Ferricore Block

