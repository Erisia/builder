---
navigation:
  title: "Ferricore Hoe"
  icon: "justdirethings:ferricore_hoe"
  position: 5
  parent: justdirethings:tools.md
item_ids:
  - justdirethings:ferricore_hoe
---

# Ferricore Hoe

This Ferricore Hoe provides an excellent tool for preparing and maintaining farmland. It is eligible for various upgrades.

When used to till dirt, the Ferricore Hoe converts it into Primogel Soil. Primogel Soil offers the benefit of being trample-proof, ensuring that your crops remain undisturbed. Crops also grow just a little bit faster

Ferricore Hoe Crafting

<Recipe id="justdirethings:ferricore_hoe" />

