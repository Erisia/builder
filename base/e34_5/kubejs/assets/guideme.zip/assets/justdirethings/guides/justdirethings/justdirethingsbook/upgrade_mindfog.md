---
navigation:
  title: "Mind Fog"
  icon: "justdirethings:upgrade_mindfog"
  position: 1
  parent: justdirethings:upgrades.md
item_ids:
  - justdirethings:upgrade_mindfog
---

# Mind Fog

This passive ability will make you harder to detect. Mobs won't be able to detect you as easily, and you can get closer to them before they start to agro on you.

Higher tiers of armor will make this ability even more effective.

## Mind Fog Upgrade Crafting



<Recipe id="justdirethings:upgrade_mindfog" />

