---
navigation:
  title: "Ferricore Boots"
  icon: "justdirethings:ferricore_boots"
  position: 4
  parent: justdirethings:armor.md
item_ids:
  - justdirethings:ferricore_boots
---

# Ferricore Boots

The Ferricore Boots are crafted for adventurers, providing slightly more protection and durability than iron boots. They can be upgraded to offer enhanced abilities like increased jumping.

## Ferricore Boots Crafting



<Recipe id="justdirethings:ferricore_boots" />

