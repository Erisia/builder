---
navigation:
  title: "Stupefy"
  icon: "justdirethings:upgrade_stupefy"
  position: 1
  parent: justdirethings:upgrades.md
item_ids:
  - justdirethings:upgrade_stupefy
---

# Stupefy

Confuse your foes with the Stupefy upgrade. When looking at an enemy and activating this ability with a hotkey, they will immediately forget about you!.

Furthermore, they won't be able to target you again for a few moments. This ability has a cooldown!

## Stupefy Upgrade Crafting



<Recipe id="justdirethings:upgrade_stupefy" />

