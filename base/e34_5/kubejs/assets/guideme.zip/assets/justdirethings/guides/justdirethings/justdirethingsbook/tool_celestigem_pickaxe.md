---
navigation:
  title: "Celestigem Pickaxe"
  icon: "justdirethings:celestigem_pickaxe[justdirethings:forge_energy=10000]"
  position: 14
  parent: justdirethings:tools.md
item_ids:
  - justdirethings:celestigem_pickaxe
---

# Celestigem Pickaxe

Enhancing the [Blazegold Pickaxe](./tool_blazegold_pickaxe.md) with Forge Energy storage, this tool holds up to 10,000 FE. For continuous use, charge with a [Pocket Generator](./item_pocket_generator.md).

Celestigem Pickaxe Crafting

<Recipe id="justdirethings:celestigem_pickaxe" />

