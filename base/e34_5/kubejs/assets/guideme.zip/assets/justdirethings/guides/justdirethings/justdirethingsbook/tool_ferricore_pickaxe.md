---
navigation:
  title: "Ferricore Pickaxe"
  icon: "justdirethings:ferricore_pickaxe"
  position: 2
  parent: justdirethings:tools.md
item_ids:
  - justdirethings:ferricore_pickaxe
---

# Ferricore Pickaxe

The Ferricore Pickaxe combines durability with efficiency, slightly outperforming iron. It can be upgraded with abilities to enhance mining capabilities.

Ferricore Pickaxe Crafting

<Recipe id="justdirethings:ferricore_pickaxe" />

