---
navigation:
  title: "Ore Miner"
  icon: "justdirethings:upgrade_oreminer"
  position: 1
  parent: justdirethings:upgrades.md
item_ids:
  - justdirethings:upgrade_oreminer
---

# Ore Miner

The Ore Miner upgrade is a passive ability which can go onto pickaxes starting at Ferricore. It automatically mines ore blocks connected to the one you mine, sort of like a 'vein miner' but only for ores, and automatic.

## Ore Miner Upgrade Crafting



<Recipe id="justdirethings:upgrade_oreminer" />

