---
navigation:
  title: "Raw Blazegold Block"
  icon: "justdirethings:raw_blazegold_ore"
  position: 2
  parent: justdirethings:resources.md
---

# Raw Blazegold Block

A Gold Block transformed by Blazebloom Goo becomes a Raw Blazegold Block. Mining this block yields Raw Blazegold items, which are smelted into [Blazegold Ingots](./res_blazegold.md).

<ItemImage id="justdirethings:raw_blazegold" />

Raw Blazegold drops when you break the Raw Blazegold Block

