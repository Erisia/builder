---
navigation:
  title: "Potion Arrow"
  icon: "justdirethings:upgrade_potionarrow"
  position: 1
  parent: justdirethings:upgrades.md
item_ids:
  - justdirethings:upgrade_potionarrow
---

# Potion Arrow

Add a magical touch to your arrows with the Potion Arrow upgrade. This upgrade allows arrows to carry potion effects, inflicting additional effects on targets.

## Potion Arrow Upgrade Crafting



<Recipe id="justdirethings:upgrade_potionarrow" />

