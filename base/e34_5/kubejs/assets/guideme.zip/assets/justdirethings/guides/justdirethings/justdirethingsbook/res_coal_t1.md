---
navigation:
  title: "Primal Coal"
  icon: "justdirethings:coal_t1"
  position: 21
  parent: justdirethings:resources.md
---

# Primal Coal

Primal Coal is the initial stage of specialized coal obtained by placing a coal block next to a [Primogel Goo](./goo_tier1.md). It lasts significantly longer than normal coal, and will generate more FE/T when used in generators or the pocket generator.

