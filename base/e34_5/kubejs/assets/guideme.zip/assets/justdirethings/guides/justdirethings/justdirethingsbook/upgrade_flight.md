---
navigation:
  title: "Flight"
  icon: "justdirethings:upgrade_flight"
  position: 1
  parent: justdirethings:upgrades.md
item_ids:
  - justdirethings:upgrade_flight
---

# Flight

Gain the power of unrestricted flight with the Flight upgrade. This upgrade allows you to fly freely in survival mode, much like in creative mode.

It does use forge energy to keep you aloft, so don't run out!

## Flight Crafting



<Recipe id="ftb:justdirethings/upgrade_flight" />

