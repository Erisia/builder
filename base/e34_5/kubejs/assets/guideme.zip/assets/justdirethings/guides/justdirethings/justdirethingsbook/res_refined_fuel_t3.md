---
navigation:
  title: "Refined Voidflame Fuel"
  icon: "justdirethings:refined_t3_fluid_bucket"
  position: 28
  parent: justdirethings:resources.md
---

# Refined Voidflame Fuel

Refined Voidflame Fuel is crafted by enhancing Unrefined Voidflame Fuel. Start by dropping [Voidflame Coal](./res_coal_t3.md) into [Refined Blaze Ember Fuel](./res_refined_fuel_t2.md). Then, expose this fluid to a VoidShimmer Goo block for refinement. This fuel variant is noted for its superior energy output compared to previous tier fuels, significantly boosting FE/T and total FE generation.

Refined Voidflame Fuel is an efficient fuel, and can be used to generate energy in the [Fuel Generator](./mach_generatorfluidt1.md).

