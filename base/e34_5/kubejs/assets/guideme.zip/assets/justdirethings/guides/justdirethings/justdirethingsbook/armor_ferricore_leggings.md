---
navigation:
  title: "Ferricore Leggings"
  icon: "justdirethings:ferricore_leggings"
  position: 3
  parent: justdirethings:armor.md
item_ids:
  - justdirethings:ferricore_leggings
---

# Ferricore Leggings

Designed for both comfort and protection, Ferricore Leggings provide enhanced durability and the option for further upgrades to increase your movement speed.

## Ferricore Leggings Crafting



<Recipe id="justdirethings:ferricore_leggings" />

