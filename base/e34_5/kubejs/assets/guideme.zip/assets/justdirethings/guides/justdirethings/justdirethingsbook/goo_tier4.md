---
navigation:
  title: "Shadowpulse Goo"
  icon: "justdirethings:gooblock_tier4"
  position: 4
  parent: justdirethings:goo.md
item_ids:
  - justdirethings:gooblock_tier4
---

# Shadowpulse Goo

At the pinnacle of goo research lies Shadowpulse Goo, capable of transforming Netherite into Eclipse Alloy. This top-tier goo enables the creation of supremely powerful items.

Shadowpulse Goo is crafted from the rarest and most powerful of materials, offering unmatched capabilities in material transformation.

## Crafting Shadowpulse Goo



<Recipe id="justdirethings:gooblock_tier4" />

