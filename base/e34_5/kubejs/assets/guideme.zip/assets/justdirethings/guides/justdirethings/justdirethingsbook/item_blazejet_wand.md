---
navigation:
  title: "Blazejet Wand"
  icon: "justdirethings:blazejet_wand"
  position: 5
  parent: justdirethings:items.md
item_ids:
  - justdirethings:blazejet_wand
---

# Blazejet Wand

The Blazejet Wand is a great way to get around! It comes with the air burst ability built in.

Activate this ability using right click (or customize it in the tool settings screen) to blast you in the direction you're facing.

Higher tiers of this wand allow you to go even further, which you can configure with a slider in the tool settings screen.

While holding this in your hand, you won't take any fall damage. But ensure its in your hand!

This tool comes with the lava repair ability, so drop it in a lava source block to repair it.

## Blazejet Wand Crafting



<Recipe id="justdirethings:blazejet_wand" />

