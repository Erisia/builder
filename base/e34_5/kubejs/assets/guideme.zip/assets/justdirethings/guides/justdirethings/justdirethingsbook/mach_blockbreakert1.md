---
navigation:
  title: "Simple Block Breaker"
  icon: "justdirethings:blockbreakert1"
  position: 3
  parent: justdirethings:machines.md
item_ids:
  - justdirethings:blockbreakert1
---

# Simple Block Breaker

The simple block breaker uses a tool (such as a pickaxe or shovel) to break the block it is facing. It cannot operate without a tool, and will damage the tool (or consume power) whenever a block is broken, just like what would happen if a player was using it.

## Simple Block Breaker



<Recipe id="justdirethings:blockbreakert1" />

