---
navigation:
  title: "Ferricore Helmet"
  icon: "justdirethings:ferricore_helmet"
  position: 1
  parent: justdirethings:armor.md
item_ids:
  - justdirethings:ferricore_helmet
---

# Ferricore Helmet

The Ferricore Helmet offers basic protection with a style reminiscent of ancient warriors. It provides slightly better defense than iron helmets and has the potential to be upgraded with unique abilities to enhance its protective qualities.

## Ferricore Helmet Crafting



<Recipe id="justdirethings:ferricore_helmet" />

