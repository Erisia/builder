---
navigation:
  title: "Raw Celestigem Block"
  icon: "justdirethings:raw_celestigem_ore"
  position: 4
  parent: justdirethings:resources.md
---

# Raw Celestigem Block

Transformed by VoidShimmer Goo, a Diamond Block becomes a Raw Celestigem Block. Mine this block to get [Celestigem](./res_celestigem.md).

