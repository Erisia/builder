---
navigation:
  title: "Portal Fluid"
  icon: "justdirethings:portal_fluid_bucket"
  position: 30
  parent: justdirethings:resources.md
item_ids:
  - justdirethings:portal_fluid_catalyst
---

# Portal Fluid

Portal fluid is required to fuel the advanced portal gun.  Start by dropping a Portal Fluid Catalyst into a block of Polymorphic Fluid.

Note that the unstable version will immediately break down anywhere outside of the end!

The catalyst needed to create the unstable fluid.

Void Shimmer goo (or higher) can then be used to stabilize the fluid. Stabilized fluid can exist outside of the end.

<Recipe id="justdirethings:portal_fluid_catalyst" />

