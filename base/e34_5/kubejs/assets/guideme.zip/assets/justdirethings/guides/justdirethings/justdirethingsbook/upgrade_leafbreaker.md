---
navigation:
  title: "Leaf Breaker"
  icon: "justdirethings:upgrade_leafbreaker"
  position: 1
  parent: justdirethings:upgrades.md
item_ids:
  - justdirethings:upgrade_leafbreaker
---

# Leaf Breaker

The leaf breaker upgrade is an activated ability. Simply right click on a leaves block to activate it, and all adjacent leaf blocks will also be broken. 

## Leaf Breaker Upgrade Crafting



<Recipe id="justdirethings:upgrade_leafbreaker" />

