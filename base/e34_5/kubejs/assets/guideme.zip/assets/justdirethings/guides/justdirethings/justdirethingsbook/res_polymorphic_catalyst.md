---
navigation:
  title: "Polymorphic Catalyst"
  icon: "justdirethings:polymorphic_catalyst"
  position: 25
  parent: justdirethings:resources.md
---

# Polymorphic Catalyst

The Polymorphic Catalyst is a key ingredient used to transform water into Polymorphic Fluid. It enables the molecular restructuring of water to accept and bond with other elemental properties, making it foundational for producing various specialized fluids within the mod.

