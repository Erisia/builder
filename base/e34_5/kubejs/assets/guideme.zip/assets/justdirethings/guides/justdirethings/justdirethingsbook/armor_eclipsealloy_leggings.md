---
navigation:
  title: "Eclipse Alloy Leggings"
  icon: "justdirethings:eclipsealloy_leggings[justdirethings:forge_energy=500000]"
  position: 22
  parent: justdirethings:armor.md
item_ids:
  - justdirethings:eclipsealloy_leggings
---

# Eclipse Alloy Leggings

Crafted for ultimate endurance, these leggings are powered by 500,000 FE of Forge Energy. Use a [Pocket Generator](./item_pocket_generator.md) to maintain their power levels and functionality.

## Eclipse Alloy Leggings Crafting



<Recipe id="justdirethings:eclipsealloy_leggings" />

