---
navigation:
  title: "Eclipse Alloy Shovel"
  icon: "justdirethings:eclipsealloy_shovel[justdirethings:forge_energy=500000]"
  position: 22
  parent: justdirethings:tools.md
item_ids:
  - justdirethings:eclipsealloy_shovel
---

# Eclipse Alloy Shovel

Eclipse Alloy Shovel is unmatched in moving large amounts of material efficiently with its enhanced energy capacity. 

Ideal for handling the toughest digging challenges.

Eclipse Alloy Shovel Crafting

<Recipe id="justdirethings:eclipsealloy_shovel" />

