---
navigation:
  title: "Eclipse Alloy Bow"
  icon: "justdirethings:bow_eclipsealloy[justdirethings:forge_energy=500000]"
  position: 25
  parent: justdirethings:tools.md
item_ids:
  - justdirethings:bow_eclipsealloy
---

# Eclipse Alloy Bow

The Eclipse Alloy Bow embodies the ultimate in ranged weaponry, providing vast energy reserves for prolonged use. 

It features 4 slots for Potion Canisters, enhancing arrows with various effects. [Potion Canister](./item_potion_canister.md)

Eclipse Alloy Bow Crafting

<Recipe id="justdirethings:bow_eclipsealloy" />

