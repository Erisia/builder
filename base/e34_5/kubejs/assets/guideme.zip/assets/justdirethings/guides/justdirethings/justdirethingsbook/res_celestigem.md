---
navigation:
  title: "Celestigem"
  icon: "justdirethings:celestigem"
  position: 5
  parent: justdirethings:resources.md
---

# Celestigem

Celestigems are obtained by mining [Raw Celestigem Blocks](./res_celestigem_raw.md). These gems possess unique properties ideal for high-tier mystical applications, including storing energy and facilitating teleportation abilities.

