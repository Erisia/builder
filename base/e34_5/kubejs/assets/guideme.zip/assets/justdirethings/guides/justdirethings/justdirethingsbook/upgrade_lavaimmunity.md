---
navigation:
  title: "Lava Immunity"
  icon: "justdirethings:upgrade_lavaimmunity"
  position: 1
  parent: justdirethings:upgrades.md
item_ids:
  - justdirethings:upgrade_lavaimmunity
---

# Lava Immunity

Protect yourself from the scorching heat of lava with the Lava Immunity upgrade. This upgrade grants complete immunity to lava damage.

It does use forge energy to keep you aloft, so don't run out!

## Lava Immunity Crafting



<Recipe id="justdirethings:upgrade_lavaimmunity" />

