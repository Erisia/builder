---
navigation:
  title: "Debuff Remover"
  icon: "justdirethings:upgrade_debuffremover"
  position: 1
  parent: justdirethings:upgrades.md
item_ids:
  - justdirethings:upgrade_debuffremover
---

# Debuff Remover

The Debuff Remover upgrade automatically clears any negative effects you receive, keeping you in peak fighting condition.

This is an activated ability, so you'll need to bind a hotkey in the tool settings screen. It also has a cooldown.

## Debuff Remover Crafting



<Recipe id="justdirethings:upgrade_debuffremover" />

