---
navigation:
  title: "VoidShimmer Goo"
  icon: "justdirethings:gooblock_tier3"
  position: 3
  parent: justdirethings:goo.md
item_ids:
  - justdirethings:gooblock_tier3
---

# VoidShimmer Goo

VoidShimmer Goo, imbued with the mysterious energies of the End, allows for the transformation of Diamonds into Celestigem. This goo tier enables the creation of materials with extraordinary properties, such as enhanced energy storage, and teleportation.
