---
navigation:
  title: "Tree Feller"
  icon: "justdirethings:upgrade_treefeller"
  position: 1
  parent: justdirethings:upgrades.md
item_ids:
  - justdirethings:upgrade_treefeller
---

# Tree Feller

Treefeller is a passive ability that goes on Ferricore Axes and above. When you break a piece of wood, it will break any adjacent matching wood blocks at the same time.

Chop down those trees in a single swing!

Note: Chopping down an entire tree at once takes a bit longer than a single block!

## Tree Feller Upgrade Crafting



<Recipe id="justdirethings:upgrade_treefeller" />

