---
navigation:
  title: "Raw Eclipse Alloy Block"
  icon: "justdirethings:raw_eclipsealloy_ore"
  position: 6
  parent: justdirethings:resources.md
---

# Raw Eclipse Alloy Block

When a Netherite Block is transformed by Shadowpulse Goo, it becomes a Raw Eclipse Alloy Block. Mine this block to obtain Raw Eclipse Alloy items, which can be smelted into [Eclipse Alloy Ingots](./res_eclipsealloy.md).

<ItemImage id="justdirethings:raw_eclipsealloy" />

Raw Eclipse Alloy drops when you break the Raw Eclipse Alloy Block

