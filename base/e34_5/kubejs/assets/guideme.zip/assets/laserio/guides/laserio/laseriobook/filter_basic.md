---
navigation:
  title: "Basic Filter"
  icon: "laserio:filter_basic"
  position: 1
  parent: laserio:filters.md
---

# Basic Filter

The basic filter can be used to limit what items are allowed in an inventory.

These slots are 'ghost slots', which means they do not REALLY hold items, just an image of an item.

If JEI is installed, you may drag items from JEI into these 'ghost slots'. Simply left click and drag out of JEI into the filter UI.

