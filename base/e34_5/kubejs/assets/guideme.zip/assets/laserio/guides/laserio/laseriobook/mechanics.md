---
navigation:
  title: "Card Mechanics"
  icon: "laserio:logic_chip"
  position: 2
---

# Card Mechanics

<SubPages />