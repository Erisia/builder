---
navigation:
  title: "Fluid Cards"
  icon: "laserio:card_fluid"
  position: 2
  parent: laserio:cards.md
item_ids:
  - laserio:card_fluid
---

# Fluid Cards

Fluid Cards are used to send Fluids between inventories, such as tanks.

Overclocker values are documented on the following page.

MB/T values (max) for Overclockers:


- 0 Overclockers: 5,000mb/20t
- 1 Overclocker:  10,000mb/15t
- 2 Overclockers: 20,000mb/10t
- 3 Overclockers: 30,000mb/5t
- 4 Overclockers: 40,000mb/1t

## Fluid Card



<Recipe id="laserio:card_fluid" />

