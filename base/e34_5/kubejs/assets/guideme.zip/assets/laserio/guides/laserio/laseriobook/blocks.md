---
navigation:
  title: "Blocks"
  icon: "laserio:laser_node"
---

# Blocks

<SubPages />